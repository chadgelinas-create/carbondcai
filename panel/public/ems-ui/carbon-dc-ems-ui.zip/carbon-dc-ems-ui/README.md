# Carbon DC EMS — Skid 2 Admin UI (prototype)

Self-contained single-file web app. All markup, CSS, and JS live in `index.html`;
telemetry is simulated in-browser (no backend, no build step).

## Deploy to Netlify
- Drag this folder (or the zip) onto the Netlify "Deploys" drop zone, **or**
- `netlify deploy --dir=. --prod`

The site root is `index.html`. Nothing to build.

## Notes
- Light/dark toggle (top-right). Theme persists via localStorage.
- Built-in UI review/annotation layer (💬 Review, bottom-right) — comments export to .md/.json.
- MPPT registers use the PDS1750K placeholder map pending the CNVTR-1/2 maps.
